
import { NextResponse } from "next/server";
import prisma from "@/lib/db/prisma";
import { userSchema } from "@/types/user";
import bcrypt from "bcryptjs";
import { signIn } from "next-auth/react";

export async function POST(req: Request) {
    try {
        const body = await req.json();
        console.log("Request Body:", body);

        const parsedData = userSchema.omit({ id: true }).safeParse(body);
        console.log("Parsed Data:", parsedData);

        if (!parsedData.success) {
            console.log("Validation Error:", parsedData.error.errors);
            return NextResponse.json({ error: parsedData.error.errors }, { status: 400 });
        }

        const { name, email, password } = parsedData.data;

        // Check if user already exists
        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            console.log("User already exists:", existingUser);
            return NextResponse.json({ error: "User already exists" }, { status: 409 });
        }

        // Hash password before saving
        const hashedPassword = await bcrypt.hash(password, 10);
        console.log("Hashed Password:", hashedPassword);

        // Create user in database
        const newUser = await prisma.user.create({
            data: {
                name,
                email,
                password: hashedPassword,
            },
        });
        console.log("New User Created:", newUser);

        // Auto-login after registration
        const loginResponse = await signIn("credentials", { email, password, redirect: false });
        console.log("Login Response:", loginResponse);

        if (loginResponse?.error) {
            console.log("Login Failed:", loginResponse.error);
            return NextResponse.json({ error: "Login failed after registration" }, { status: 500 });
        }

        return NextResponse.json({ message: "User registered and logged in successfully", user: newUser }, { status: 201 });

    } catch (error) {
        console.error("Error in registration:", error);
        return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
    }
}
