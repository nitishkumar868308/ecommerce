import { NextResponse } from "next/server";
import prisma from "@/lib/db/prisma";
import bcrypt from "bcryptjs";
import { userSchema } from "@/types/user";
import { signIn } from "next-auth/react";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    console.log("Request Body:", body); // 🛠 Debugging Log

    const parsedData = userSchema.pick({ email: true, password: true }).safeParse(body);
    console.log("Parsed Data:", parsedData); // 🛠 Debugging Log

    if (!parsedData.success) {
      console.error("Validation Error:", parsedData.error.errors);
      return NextResponse.json({ error: parsedData.error.errors }, { status: 400 });
    }

    const { email, password } = parsedData.data;

    // ✅ Find user by email
    const user = await prisma.user.findUnique({ where: { email } });
    console.log("User Found:", user); // 🛠 Debugging Log

    if (!user) {
      console.error("User not found for email:", email);
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // ✅ Compare password
    const isValid = await bcrypt.compare(password, user.password);
    console.log("Password Match:", isValid); // 🛠 Debugging Log

    if (!isValid) {
      console.error("Invalid credentials for user:", email);
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }

    // ✅ Start session with NextAuth
    const signInResponse = await signIn("credentials", { email, password, redirect: false });
    console.log("SignIn Response:", signInResponse); // 🛠 Debugging Log

    if (signInResponse?.error) {
      console.error("Login failed for user:", email, signInResponse.error);
      return NextResponse.json({ error: "Login failed" }, { status: 401 });
    }

    return NextResponse.json({ message: "Login successful", user }, { status: 200 });
  } catch (error) {
    console.error("Error in login:", error); // 🛠 Debugging Log
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
