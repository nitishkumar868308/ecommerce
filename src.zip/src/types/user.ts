import { z } from "zod";

// User Zod Schema
export const userSchema = z.object({
    id: z.number().int().positive().optional(), // Optional since Prisma auto-generates it
    name: z.string().min(1, "Name is required"),
    email: z.string().email("Invalid email address"),
    password: z.string().min(6, "Password must be at least 6 characters"),
    createdAt: z.union([z.string(), z.date()]).optional(),
    updatedAt: z.union([z.string(), z.date()]).optional(),
});

export type User = z.infer<typeof userSchema>;

// Interfaces
export interface IUserName {
    name: string;
}

export interface IUserSignIn {
    email: string;
    password: string;
}

export interface IUserSignUp extends IUserSignIn {
    name: string;
    confirmPassword: string;
}
